﻿#pragma once

#include "cocos2d.h"
#include "cocos-ext.h"
#include "ExtensionMacros.h"
